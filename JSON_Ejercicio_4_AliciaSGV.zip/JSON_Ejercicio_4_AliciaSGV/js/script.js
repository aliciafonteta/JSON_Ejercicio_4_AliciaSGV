// FUENTES EXTERNAS: datos sobre createElement (el .before y los usos y creacion del select) en mdn web, 
// explicacion de por qué no aparecian correctamente los elementos en pantalla cuando ya tenía todo creado y funcionalidades dadas en la ia bolt.new (me explicó que debo poner la función fetchantes si se trata de API, lo apunté abajo como nota para mi)
// tutorial de array.filter() :https://www.freecodecamp.org/espanol/news/tutorial-de-arrayfilter-de-javascript-como-iterar-a-traves-de-los-elementos-en-un-arreglo/

//------------------------------------------------ Contenedor y desplegable para filtro ----------------------------------------------------------
const contenedor = document.querySelector("main");

const filtro = document.createElement("select"); // el elemento select que creamos es una lista desplegable 
filtro.id = "category-filter"; // Le asignamos un id
contenedor.before(filtro); // Insertamos el filtro antes de las tarjetas (web mdn en el metodo createElement)


// ---------------------------------------------------------------- cargar API con fetch ----------------------------------------
fetch('https://www.themealdb.com/api/json/v1/1/categories.php')
  .then(response => response.json()) // Convertimos la respuesta en formato JSON
  .then(data => {

    // Verificamos que la API tenga categorias y si no, que mande un mensaje en la consola
    if (!data.categories) { 
      console.error("No se encontraron categorías en la API.");
      return;
    }

    // Aquí se crea el array de categorias pidiendole a la api las categorias que tiene y las guardamos en una variable
    const categorias = data.categories; 

    // ----------------- pone TODAS en el desplegable
    const opcionTodas = document.createElement("option"); 
    opcionTodas.value = "VerTodas"; 
    opcionTodas.textContent = "Todas las categorías"; 
    filtro.appendChild(opcionTodas); // Añadimos la opción al filtro

    // ------------------ pone el resto de las opciones de categorias

    categorias.forEach(category => { //para cada categoria creamos una opcion
      const option = document.createElement("option");
      option.value = category.strCategory;
      option.textContent = category.strCategory;
      filtro.appendChild(option); // Añadimos las opciones
    });

    // Muestra el array de categorias que hemos creado antes y lo usa
    mostrar_Categorias(categorias);

    // Evento para filtrar, (tuto de array.filter)

    filtro.addEventListener("click", () => {  
      const categoria_Seleccionada = filtro.value;//para que se quede con el nombre de la categoria seleccionada
    
      let categorias_Filtradas;
      if (categoria_Seleccionada === "VerTodas") {
        categorias_Filtradas = categorias;
      } else {
        categorias_Filtradas = categorias.filter(elemento => elemento.strCategory === categoria_Seleccionada); 
      }
    
      mostrar_Categorias(categorias_Filtradas); // mostrará solo las que cumplan el filtro
    
    });
  })
  .catch(error => console.error("Error al cargar las categorías:", error));


// Función para mostrar las categorías en el DOM
function mostrar_Categorias(categorias) {
  contenedor.innerHTML = ""; // Limpiar el contenido actual antes de agregar nuevas tarjetas
  categorias.forEach(crearCard); // Llamamos a la función para crear las tarjetas
}

// ---------------------------------------------------------------- CARDS ---------------------------------------------------------
function crearCard(category) {

  // ------- El div 
  const card = document.createElement("div");
  card.classList.add("categories-card");     //la clase

  // ------- Crea las imagenes metodo nodo appendChild() 
  const picture = document.createElement("picture");

  const img = document.createElement("img");
  img.classList.add("categories-image");          //clase
  img.setAttribute("src", category.strCategoryThumb);  //atributo
  img.setAttribute("alt", category.strCategory);         //atributo

  // ------- Añade las imagenes como hijos
  picture.appendChild(img);

   // ------- categoria de la receta
  const categoria = document.createElement("h3");
  categoria.classList.add("categories-category");
  categoria.textContent = category.idCategory;  

  // ------ nombre producto
  const nombre = document.createElement("h2");
  nombre.classList.add("categories-name");
  nombre.textContent = category.strCategory;

  // ------ tipo producto
  const descripcion = document.createElement("p");
  descripcion.classList.add("categories-descript");
  descripcion.textContent = category.strCategoryDescription;

  // ------------------------------------ añadir a la card todos los elementos que he creado antes
  card.appendChild(picture);
  card.appendChild(categoria);
  card.appendChild(nombre);
  card.appendChild(descripcion);

  // ------------------------------------añadimos la card al contenedor
  contenedor.appendChild(card);

}




//NOTA: En este caso la funcion Fetch tiene que estar arriba porque utilizamos Api para traer los datos de forma remota y podrian tardar, lo que haria que se crearan "datos vacios" y diera error al cargar las cards (forma ASINCRÓNICA)
// en el caso de info con archivos JSON dentro del propio trabajo no habri problema porque no se cargarian las cards hasta que se leyeran todos los datos del documento y esto sera inmediato (forma SINCRÓNICA)